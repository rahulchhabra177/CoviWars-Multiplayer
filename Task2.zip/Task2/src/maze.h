#ifndef MAZE_H

#define MAZE_H
#include<bits/stdc++.h>
#include "Texture.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
using namespace std;

class Maze{

	public:
		
		int m_width=27;			
		int m_height=21;
		int lvl=1;
		SDL_Texture* wTexture = NULL;
		SDL_Texture* sTexture = NULL;
		SDL_Texture* dTexture = NULL;
		vector<vector<int>> mazeData;
		void reinitialize();
		Maze(int l,SDL_Renderer* localRenderer,string mzData);
		void render(SDL_Renderer* renderer);
		SDL_Rect mazeCell,mazeEgg;
		void update();
		string getMazeState();
		
	private:
		
		void constructMaze();
		void removeDeadEnds();
		int openCell(int i,int j);
		vector<int> neighbours(pair<int,int> coord);
		void setWinCondition();

};

#endif
