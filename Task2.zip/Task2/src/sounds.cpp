#include "sounds.h";

using namespace std;
bool sound_debug=true;

SoundClass::SoundClass(){
	if (sound_debug)cout<<"sounds.cpp:SoundClass\n";

	int res=Mix_OpenAudio(22050,AUDIO_S16SYS,2,4069);
	//Here First parameter is audio rate ,Second paramerter is audio_format ,Third parameter is number of audio channels,last parameter is for audio buffer
	if (res!=0){
		cout<<"Couldn't initialize audio:"<<Mix_GetError()<<"\n";
		exit(1);
	}	
}


void SoundClass::LoadSound(char* path,string label){
	if (sound_debug)cout<<"sounds.cpp:LoadSound\n";
	Mix_Chunk * sound_chunk=Mix_LoadWAV(path);
	if (sound_chunk==nullptr){
		cout<<"Couldn't initialize sound at :"<<path<<"::"<<Mix_GetError()<<"\n";
		exit(1);
	}
	LabelToInt[label]=size_it;

	SoundVector.push_back(sound_chunk);
	size_it++;

}
void SoundClass::LoadMusic(char* path,string label){
	if (sound_debug)cout<<"sounds.cpp:LoadSound\n";
	Mix_Music * musicchunk=Mix_LoadMUS(path);
	if (musicchunk==nullptr){
		cout<<"Couldn't initialize sound at :"<<path<<"::"<<Mix_GetError()<<"\n";
		exit(1);
	}
	LabelToInt1[label]=size_it1;

	MusicVector.push_back(musicchunk);
	size_it1++;

}

void SoundClass::InitializeAll(){
	if (sound_debug)cout<<"sounds.cpp:InitializeAll\n";
	LoadSound("./../Sounds/start.wav","start");
	LoadSound("./../Sounds/pauseState.wav","pause");
	LoadSound("./../Sounds/collision.wav","collision");
	LoadSound("./../Sounds/menuStart.wav","gamestart");
	LoadSound("./../Sounds/bPress.wav","button");
	LoadMusic("./../Sounds/bMusic.mp3","bMusic");
}

void SoundClass::PlaySound(string label){
	if (sound_on){
	if (sound_debug)cout<<"sounds.cpp:PlaySound\n";
	Mix_HaltChannel(-1);

	// cout<<size_it<<"\n";
	int loc=LabelToInt[label];
	// cout<<loc<<" "<<label<<"\n";
	Mix_PlayChannel(-1,SoundVector.at(loc),0);
}
}

void SoundClass::PlayMusic(string label){
	if (music_on){
	if (sound_debug)cout<<"sounds.cpp:PlaySound\n";
	// Mix_HaltChannel(-1);

	// cout<<size_it1<<"\n";
	int loc=LabelToInt1[label];
	cout<<loc<<" "<<label<<"\n";
	Mix_PlayMusic(MusicVector.at(loc),-1);
}
}


void SoundClass::changeMusicState(bool state){
	if (!state){Mix_PauseMusic();}
	else{Mix_ResumeMusic();}
	music_on=state;
}


void SoundClass::changeSoundState(bool state){
	if (!state){Mix_HaltChannel(-1);}
	sound_on=state;
}